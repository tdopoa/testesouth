﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TesteSouth;

namespace TesteSouthSystem
{
    class Program
    {

        private static readonly string dirDataIn = Environment.CurrentDirectory + "\\Data\\in\\";
        private static readonly string dirDataOut = Environment.CurrentDirectory + "\\Data\\out\\";

        private static List<Vendedor> vendedores = new List<Vendedor>();
        private static List<Cliente> clientes = new List<Cliente>();
        private static List<Itens> itensVendas = new List<Itens>();
        private static List<Vendas> vendas = new List<Vendas>();

        static void Main(string[] args)
        {
            Console.WriteLine("Processamento de arquivos");
            Console.WriteLine("Copie os arquivos a serem processados para o diretório " + dirDataIn);
            Console.WriteLine("e após isso, verifique o resultado do processamento no diretório " + dirDataOut);
            listen();

            new System.Threading.AutoResetEvent(false).WaitOne();
        }


        private static void listen()
        {
            if (!Directory.Exists(dirDataIn))
            {
                Console.WriteLine("Caminho de diretório inválido");
                Console.ReadLine();
            }
            else
            {
                FileSystemWatcher fsw = new FileSystemWatcher(dirDataIn);
                fsw.Filter = "*.dat";

                WaitForChangedResult wcr = fsw.WaitForChanged(WatcherChangeTypes.All, 1000);
                fsw.NotifyFilter = NotifyFilters.LastAccess | NotifyFilters.LastWrite | NotifyFilters.FileName | NotifyFilters.DirectoryName;
                fsw.EnableRaisingEvents = true;
                fsw.Created += new FileSystemEventHandler(OnCreated);
            }

        }

        private static void OnCreated(object source, FileSystemEventArgs e)
        {
            Console.WriteLine($"Arquivo {e.Name} criado ");
            getInfoFile(e.Name);
        }

        private static void getInfoFile(string FileName)
        {
            if(!File.Exists(dirDataIn + FileName))
            {
                return;
            }

            string[] rows = File.ReadAllLines(dirDataIn + FileName);
            Console.WriteLine("Coletando informações do arquivo...");
            foreach (string row in rows)
            {
                string[] columns = row.Split('ç');

                // Dados Vendedor
                if (columns[0].Equals("001"))
                {
                    Vendedor vendedor = new Vendedor();
                    vendedor.CPF = columns[1];
                    vendedor.Nome = columns[2];
                    vendedor.Salario = Convert.ToDecimal(columns[3]);
                    vendedores.Add(vendedor);
                }

                // Dados Vendedor
                if (columns[0].Equals("002"))
                {
                    Cliente cliente = new Cliente();
                    cliente.CNPJ = columns[1];
                    cliente.Nome = columns[2];
                    cliente.BusinessArea = columns[3];
                    clientes.Add(cliente);
                }

                // Dados Vendas
                if (columns[0].Equals("003"))
                {
                    Vendas venda = new Vendas();
                    venda.ID = Convert.ToInt32(columns[1]);

                    // Itens
                    string sItens = columns[2].Replace("[", "").Replace("]", "");
                    string[] Itens = sItens.Split(',');
                    foreach (string i in Itens)
                    {
                        string[] itemVenda = i.Split('-');
                        Itens item = new Itens();
                        item.ID = Convert.ToInt32(itemVenda[0]);
                        item.Quantidade = Convert.ToInt32(itemVenda[1]);
                        item.Valor = Convert.ToDecimal(itemVenda[2]);
                        item.Total = item.Quantidade * item.Valor;
                        itensVendas.Add(item);
                    }

                    venda.Itens = itensVendas;
                    venda.TotalVendas = (from iv in itensVendas select iv.Total).Sum();
                    venda.NomeVenderor = columns[3];
                    vendas.Add(venda);
                }
            }

            MontaArquivoSaida(FileName);
        }



        private static void MontaArquivoSaida(string fileName)
        {
            // Monta string com resumo da informações
            int QtdClientes = (from c in clientes select c.CNPJ).Count();
            int QtdVendedores = (from v in vendedores select v.CPF).Count();
            int idVendaMaisCara = (from v in vendas orderby v.TotalVendas descending select v.ID).FirstOrDefault();
            string piorVendedor = (from v in vendas orderby v.TotalVendas ascending select v.NomeVenderor).FirstOrDefault();

            string sResume = "Total de clientes : " + QtdClientes.ToString() + Environment.NewLine;
            sResume += "Total de Vendedores : " + QtdVendedores.ToString() + Environment.NewLine;
            sResume += "ID Venda mais Cara: " + idVendaMaisCara.ToString() + Environment.NewLine;
            sResume += "Pior Vendedor: " + piorVendedor + Environment.NewLine;

            // Apaga se o arquivo já existe
            if (File.Exists(dirDataOut + "\\" + fileName.Replace(".dat", ".done.dat")))
            {
                Console.WriteLine("Apagando arquivo de saída...");
                File.Delete(dirDataOut + "\\" + fileName.Replace(".dat", ".done.dat"));
            }
            else
            {
                using (FileStream fs = File.Create(dirDataOut + "\\" + fileName.Replace(".dat", ".done.dat")))
                {
                    Byte[] title = new UTF8Encoding(true).GetBytes(sResume);
                    fs.Write(title, 0, title.Length);
                }
                Console.WriteLine("Apagando arquivo de origem.. ");
                File.Delete(dirDataIn + "\\" + fileName);
                Console.WriteLine("Arquivo de origem apagado.");

                Console.WriteLine(fileName.Replace(".dat", ".done.dat"));
                Console.WriteLine("Arquivo de saída gerado com sucesso! ");
                Console.WriteLine("------------------------------------------------------------------------------------");
            }
        }
    }
}
