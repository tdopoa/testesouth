﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TesteSouth
{
    class Vendedor
    {
        public string CPF { get; set; }
        public string Nome { get; set; }
        public decimal Salario { get; set; }
    }
}
