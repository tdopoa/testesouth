﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TesteSouth
{
    class Vendas
    {
        public int ID { get; set; }
        public List<Itens> Itens { get; set; }
        public string NomeVenderor { get; set; }
        public decimal TotalVendas { get; set; }
    }
}
